﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBMS_PROJ
{
    public partial class addcategory : Form
    {
        public addcategory()
        {
            InitializeComponent();
        }
        const string constr = @"Data Source = DESKTOP-OGFUFDG\SPARTA; Initial Catalog=PROJECT; User ID=sa; Password=BRIGHTSHINES#95; Integrated Security=SSPI";
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cm = new SqlCommand();

        private void button1_Click(object sender, EventArgs e)
        {
            string categoryname;
            categoryname = textBox1.Text;
            con.Open();
            string sql1 = "INSERT INTO Book_Category(Category_Name)\r\nVALUES (@categoryname)";
            cm = new SqlCommand(sql1, con);
            cm.Parameters.AddWithValue("@categoryname", categoryname);
            cm.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("CATEGORY ADDED SUCCESSFULLY");
            this.Close();
        }

        private void addcategory_Load(object sender, EventArgs e)
        {

        }
    }
}
