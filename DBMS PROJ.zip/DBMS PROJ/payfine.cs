﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DBMS_PROJ
{
    public partial class payfine : Form
    {
        public payfine()
        {
            InitializeComponent();
        }
        const string constr = @"Data Source = DESKTOP-OGFUFDG\SPARTA; Initial Catalog=PROJECT; User ID=sa; Password=BRIGHTSHINES#95; Integrated Security=SSPI";
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cm = new SqlCommand();

        private void payfine_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            borrowerform borrowerform = new borrowerform();
            borrowerform.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd9 = new SqlCommand("select Borrower_Details.Book_ID, Book_Name,Return_Date,Fine from Borrower_Details,Books where Borrower_Details.Book_ID = Books.Book_ID AND getDate() > Return_Date And Student_ID = @stdid", con);
            cmd9.Parameters.AddWithValue("@stdid", textBox1.Text);
            SqlDataAdapter da7 = new SqlDataAdapter(cmd9);
            DataSet ds7 = new DataSet();
            da7.Fill(ds7);
            cmd9.ExecuteNonQuery();

            con.Close();
            comboBox1.DataSource = ds7.Tables[0];
            comboBox1.DisplayMember = "Book_Name";
            comboBox1.ValueMember = "Book_ID";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            if (checkBox1.Checked)
            {
                SqlCommand cmd4 = new SqlCommand("UPDATE Borrower_Details SET Fine = 0 WHERE Student_ID = @stdid AND Book_ID = @bkid", con);
                cmd4.Parameters.AddWithValue("@stdid", textBox1.Text);
                cmd4.Parameters.AddWithValue("@bkid", comboBox1.SelectedValue);
                SqlDataAdapter da4 = new SqlDataAdapter(cmd4);
                DataSet ds4 = new DataSet();
                da4.Fill(ds4);
            }
            else
            {
                MessageBox.Show("PLEASE PAY THE FINE!");
            }
            con.Close();
            
        }
    }
}
