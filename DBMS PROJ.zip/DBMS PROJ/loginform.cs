using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;



namespace DBMS_PROJ
{
    public partial class loginform : Form
    {

        public loginform()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-OGFUFDG\SPARTA;Initial Catalog=""PROJECT"";Integrated Security=True");





        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txt_LoginID_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button_login_Click(object sender, EventArgs e)
        {
            string LoginID, Password;
            LoginID = txt_LoginID.Text;
            Password = txt_Password.Text;

            try
            {
                String querry = "SELECT * FROM Admin WHERE Admin_ID = '"+txt_LoginID.Text+"' AND acc_password = '"+txt_Password.Text+"'";
                SqlDataAdapter sda = new SqlDataAdapter(querry, conn);
                DataTable dtable = new DataTable();
                sda.Fill(dtable);

                if (dtable.Rows.Count > 0)
                {
                    LoginID = txt_LoginID.Text;
                    Password = txt_Password.Text;

                    //menuform (page that needs to be loaded next)
                    if (LoginID == txt_LoginID.Text && Password == txt_Password.Text)
                    {
                        adminres adminres = new adminres();
                        adminres.Show();
                        this.Hide();
                    }

                }
                else
                {
                    MessageBox.Show("Invalid login details", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txt_LoginID.Clear();
                    txt_Password.Clear();

                    txt_LoginID.Focus();

                }
            }
            catch
            {
                MessageBox.Show("Error, Invalid Credentials");
            }
            finally
            {
                conn.Close();
            }
        }

        private void button_clear_Click(object sender, EventArgs e)
        {
            txt_LoginID.Clear();
            txt_Password.Clear();

            txt_LoginID.Focus();

        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void txt_Password_TextChanged(object sender, EventArgs e)
        {
            txt_Password.PasswordChar = '\u25CF';
        }
    }
}
