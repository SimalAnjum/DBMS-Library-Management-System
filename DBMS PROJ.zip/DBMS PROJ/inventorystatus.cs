﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace DBMS_PROJ
{
    public partial class inventorystatus : Form
    {
        public inventorystatus()
        {
            InitializeComponent();
        }
        const string constr = @"Data Source = DESKTOP-OGFUFDG\SPARTA; Initial Catalog=PROJECT; User ID=sa; Password=BRIGHTSHINES#95; Integrated Security=SSPI";
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cm = new SqlCommand();
        private void button2_Click(object sender, EventArgs e)
        {
            string sql = "Select Book_ID, Book_Name, Category_Name, Author_Name, Publisher_Name, Publication_Date, Availaibility from Books,Publishers, Authors, Book_Category where Books.Category_ID = Book_Category.Category_ID AND Books.Publisher_ID = Publishers.Publisher_ID AND Authors.Author_ID = Books.Author_ID";

            cm = new SqlCommand(sql, con);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter(cm);
            DataTable d = new DataTable();
            da.Fill(d);
            dataGridView1.DataSource = d;
            cm.Dispose();
            con.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            adminres adminres = new adminres();
            adminres.Show();
            this.Hide();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string sql2 = "select Borrower_Details.Book_ID, Books.Book_Name from Books,Borrower_Details where Books.Book_ID = Borrower_Details.Book_ID";
            cm = new SqlCommand(sql2, con);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter(cm);
            DataTable d = new DataTable();
            da.Fill(d);
            dataGridView1.DataSource = d;
            cm.Dispose();
            con.Close();
        }

        private void inventorystatus_Load(object sender, EventArgs e)
        {

        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }
    }
}
