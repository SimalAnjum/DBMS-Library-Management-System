﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DBMS_PROJ
{
    public partial class returnbook : Form
    {
        public returnbook()
        {
            InitializeComponent();
        }
        const string constr = @"Data Source = DESKTOP-OGFUFDG\SPARTA; Initial Catalog=PROJECT; User ID=sa; Password=BRIGHTSHINES#95; Integrated Security=SSPI";
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cm = new SqlCommand();
      //  void filllistbox()
        //{
          //  var studentid = Convert.ToString(textBox1.Text);
            //string sql = "select * from Books,[Borrower_Details] where Books.Book_ID=[Borrower_Details].Book_ID and Student_ID=@studentid";
            //cm = new SqlCommand(sql, con);
            //cm.Parameters.AddWithValue("@studentid", studentid);
            //SqlDataReader myreader;
            //try
            //{
              //  con.Open();
                //myreader = cm.ExecuteReader();
                //while (myreader.Read())
                //{
                 //   string BookName = myreader.GetString("Book_Name");
                   // comboBox1.Items.Add(BookName);
                //}
                //con.Close();
            //}
            //catch (Exception ex)
            //{
             //   MessageBox.Show(ex.Message);
            //}
        //}

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            adminres adminres = new adminres();
            adminres.Show();
            this.Hide();
        }

        private void returnbook_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            adminres adminres = new adminres();
            adminres.Show();
            this.Hide();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cm = new SqlCommand("select * from Books,[Borrower_Details] where Books.Book_ID=[Borrower_Details].Book_ID and Student_ID=@studentid", con);
            cm.Parameters.AddWithValue("@studentid", textBox1.Text);
            SqlDataAdapter da3 = new SqlDataAdapter(cm);
            DataSet ds3 = new DataSet();
            da3.Fill(ds3);
            cm.ExecuteNonQuery();

            con.Close();
            comboBox1.DataSource = ds3.Tables[0];
            comboBox1.DisplayMember = "Book_Name";
            comboBox1.ValueMember = "Book_ID";
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd1 = new SqlCommand("DELETE FROM Borrower_Details WHERE Student_ID = @stdid AND Borrow_ID = @bid", con);
            SqlCommand cmd2 = new SqlCommand("UPDATE Books SET Availaibility = 'True' WHERE Book_ID = @bid",con);
            cmd1.Parameters.AddWithValue("@stdid", textBox1.Text);
            cmd1.Parameters.AddWithValue("@bid",comboBox1.SelectedValue);
            SqlDataAdapter da2 = new SqlDataAdapter(cmd1);
            DataSet ds2 = new DataSet();
            da2.Fill(ds2);
            cmd1.ExecuteNonQuery();
            MessageBox.Show("BOOK RETURNED SUCCESSFULLY!");
            con.Close();

        }
    }
}
