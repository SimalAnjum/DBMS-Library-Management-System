﻿using System.Data;
using System.Data.SqlClient;
using System.Security.Policy;
using System.Windows.Forms;

namespace DBMS_PROJ
{
    public partial class newform : Form
    {
        public newform()
        {
            InitializeComponent();
        }
        const string constr = @"Data Source = DESKTOP-OGFUFDG\SPARTA; Initial Catalog=PROJECT; User ID=sa; Password=BRIGHTSHINES#95; Integrated Security=SSPI";
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cm = new SqlCommand();

        private void Form1_Load(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from Authors", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteNonQuery();

            con.Close();
            comboBox1.DataSource = ds.Tables[0];
            comboBox1.DisplayMember = "Author_Name";
            comboBox1.ValueMember = "Author_ID";

            con.Open();
            SqlCommand cmd1 = new SqlCommand("select * from Publishers", con);
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            DataSet ds1 = new DataSet();
            da1.Fill(ds1);
            cmd1.ExecuteNonQuery();

            con.Close();
            comboBox2.DataSource = ds1.Tables[0];
            comboBox2.DisplayMember = "Publisher_Name";
            comboBox2.ValueMember = "Publisher_ID";

            con.Open();
            SqlCommand cmd2 = new SqlCommand("select * from Book_Category", con);
            SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
            DataSet ds2 = new DataSet();
            da2.Fill(ds2);
            cmd2.ExecuteNonQuery();

            con.Close();
            comboBox4.DataSource = ds2.Tables[0];
            comboBox4.DisplayMember = "Category_Name";
            comboBox4.ValueMember = "Category_ID";

            con.Open();
            SqlCommand cmd3 = new SqlCommand("select * from Books", con);
            SqlDataAdapter da3 = new SqlDataAdapter(cmd3);
            DataSet ds3 = new DataSet();
            da3.Fill(ds3);
            cmd3.ExecuteNonQuery();

            con.Close();
            comboBox3.DataSource = ds3.Tables[0];
            comboBox3.DisplayMember = "Book_Name";
            comboBox3.ValueMember = "Book_ID";




        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox1.Focus();
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            adminres adminres = new adminres();
            adminres.Show();
            this.Hide();
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

            con.Open();
            string sql = "INSERT INTO Books(Book_Name,Category_ID,Pages,Publisher_ID,Availaibility,Author_ID,Publication_Date) values" 
                +"(@bookname,@categoryid,@pages,@publisherid,@availaibility, @authorid, @publicationdate)";
            cm = new SqlCommand(sql, con);

            cm.Parameters.AddWithValue("@bookname", textBox1.Text);
            cm.Parameters.AddWithValue("@categoryid",comboBox2.SelectedValue);
            cm.Parameters.AddWithValue("@pages", Convert.ToInt32(textBox9.Text));
            cm.Parameters.AddWithValue("@publisherid",comboBox4.SelectedValue);
            cm.Parameters.AddWithValue("@availaibility", checkBox1.Checked);
            cm.Parameters.AddWithValue("@authorid",comboBox1.SelectedValue);
            cm.Parameters.AddWithValue("@publicationdate", dateTimePicker1.Value);

            cm.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("BOOK ADDED SUCCESSFULLY!");
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            addcategory addcategory = new addcategory();
            addcategory.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            addpublisher addpublisher = new addpublisher();
            addpublisher.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            addauthor addauthor = new addauthor();
            addauthor.Show();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            string sql = "Select Book_ID, Book_Name, Category_Name, Author_Name, Publisher_Name, Publication_Date, Availaibility from Books,Publishers, Authors, Book_Category where Books.Category_ID = Book_Category.Category_ID AND Books.Publisher_ID = Publishers.Publisher_ID AND Authors.Author_ID = Books.Author_ID AND Availaibility = 'True' ";

            cm = new SqlCommand(sql, con);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter(cm);
            DataTable d = new DataTable();
            da.Fill(d);
            dataGridView1.DataSource = d;
            cm.Dispose();
            con.Close();
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string deletequery = "DELETE FROM Books WHERE Book_ID = @bookid";
            cm = new SqlCommand(deletequery, con);
            cm.Parameters.AddWithValue("@bookid", comboBox3.SelectedValue);
            con.Close();
            MessageBox.Show("BOOK DELETED SUCCESSFULLY");

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
