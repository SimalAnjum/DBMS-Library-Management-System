﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBMS_PROJ
{
    public partial class bookallotment : Form
    {
        public bookallotment()
        {
            InitializeComponent();
            fillcombobox();
        }
        const string constr = @"Data Source = DESKTOP-OGFUFDG\SPARTA; Initial Catalog=PROJECT; User ID=sa; Password=BRIGHTSHINES#95; Integrated Security=SSPI";
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cm = new SqlCommand();
        void fillcombobox()
        {
            string sql = "select * from Books";
            cm = new SqlCommand(sql, con);
            SqlDataReader myreader;
            try
            {
                con.Open();
                myreader = cm.ExecuteReader();
                while (myreader.Read())
                {
                    string BookName = myreader.GetString("Book_Name");
                    comboBox1.Items.Add(BookName);
                }
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void label2_Click(object sender, EventArgs e)
        {

        }
        private void BorrowBook()
        {
            con.Open();
            string sql = "insert into [Borrower_Details] (Student_ID, Book_ID, Return_Date, Issue_Date, Fine) values (@studentid,@bookid,@rd,GETDATE(),@fine)";
            cm = new SqlCommand(sql, con);
            cm.Parameters.AddWithValue("@studentid", textBox1.Text);
            cm.Parameters.AddWithValue("@bookid",comboBox1.SelectedValue);
            cm.Parameters.AddWithValue("@rd", dateTimePicker1.Value);
            cm.Parameters.AddWithValue("@fine", 0);
            Console.WriteLine(comboBox1.SelectedValue);
            cm.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("BOOK ALLOTED SUCCESSFULLY!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            adminres adminres = new adminres(); 
            adminres.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            
        }

        private void bookallotment_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cm = new SqlCommand("select * from Books WHERE Availaibility = 'True'", con);
            //cm.Parameters.AddWithValue("@studentid", textBox1.Text);
            SqlDataAdapter da3 = new SqlDataAdapter(cm);
            DataSet ds3 = new DataSet();
            da3.Fill(ds3);
            cm.ExecuteNonQuery();

            
            comboBox1.DataSource = ds3.Tables[0];
            comboBox1.DisplayMember = "Book_Name";
            comboBox1.ValueMember = "Book_ID";
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            BorrowBook();
        }
    }
}
