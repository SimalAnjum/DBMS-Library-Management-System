﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DBMS_PROJ
{
    public partial class borrowerform : Form
    {
        public borrowerform()
        {
            InitializeComponent();
        }
        const string constr = @"Data Source = DESKTOP-OGFUFDG\SPARTA; Initial Catalog=PROJECT; User ID=sa; Password=BRIGHTSHINES#95; Integrated Security=SSPI";
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cm = new SqlCommand();

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            adminres adminres = new adminres();
            adminres.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void borrowerform_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {


            con.Open();

            SqlCommand cmd5 = new SqlCommand("select Borrower_Details.Book_ID, Book_Name, Return_Date, Issue_Date from Borrower_Details,Books where Books.Book_ID = Borrower_Details.Book_ID AND Student_ID = @stdid", con);
            cmd5.Parameters.AddWithValue("@stdid", textBox1.Text);

            SqlDataAdapter db = new SqlDataAdapter(cmd5);
            DataTable d1 = new DataTable();
            db.Fill(d1);
            dataGridView1.DataSource = d1;

            con.Close();




        }

        private void button5_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd7 = new SqlCommand("select Borrower_Details.Book_ID, Book_Name from Borrower_Details,Books where Borrower_Details.Book_ID = Books.Book_ID AND getDate() > Return_Date And Student_ID = @stdid", con);
            cmd7.Parameters.AddWithValue("@stdid", textBox1.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd7);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd7.ExecuteNonQuery();

            con.Close();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd3 = new SqlCommand("UPDATE Students SET Flag = @cb where Student_ID = @stdid", con);
            cmd3.Parameters.AddWithValue("@stdid", textBox2.Text);
            cmd3.Parameters.AddWithValue("@cb", checkBox1.Checked);
            SqlDataAdapter da3 = new SqlDataAdapter(cmd3);
            DataSet ds3 = new DataSet();
            da3.Fill(ds3);
            cmd3.ExecuteNonQuery();
            

            con.Close();

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            con.Open();
           
            SqlCommand cmd4 = new SqlCommand("UPDATE Borrower_Details SET Fine = @fine WHERE Student_ID = @stdid AND Book_ID = @bkid", con);
            cmd4.Parameters.AddWithValue("@fine", Convert.ToInt32(textBox2.Text));
            cmd4.Parameters.AddWithValue("@stdid", textBox1.Text);
            cmd4.Parameters.AddWithValue("@bkid", comboBox1.SelectedValue);
            SqlDataAdapter da4 = new SqlDataAdapter(cmd4);
            DataSet ds4 = new DataSet();
            da4.Fill(ds4);
            cmd4.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("FINE ADDED SUCCESSFULLY");
        }

        private void button6_Click(object sender, EventArgs e)
        {



            con.Open();
            SqlCommand cmd8 = new SqlCommand("select Borrower_Details.Book_ID, Book_Name,Return_Date,Fine from Borrower_Details,Books where Borrower_Details.Book_ID = Books.Book_ID AND getDate() > Return_Date And Student_ID = @stdid", con);
            cmd8.Parameters.AddWithValue("@stdid", textBox1.Text);

            SqlDataAdapter db = new SqlDataAdapter(cmd8);
            DataTable d1 = new DataTable();
            db.Fill(d1);
            dataGridView2.DataSource = d1;

            con.Close();
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd9 = new SqlCommand("select Borrower_Details.Book_ID, Book_Name,Return_Date,Fine from Borrower_Details,Books where Borrower_Details.Book_ID = Books.Book_ID AND getDate() > Return_Date And Student_ID = @stdid", con);
            cmd9.Parameters.AddWithValue("@stdid", textBox1.Text);
            SqlDataAdapter da7 = new SqlDataAdapter(cmd9);
            DataSet ds7 = new DataSet();
            da7.Fill(ds7);
            cmd9.ExecuteNonQuery();

            con.Close();
            comboBox1.DataSource = ds7.Tables[0];
            comboBox1.DisplayMember = "Book_Name";
            comboBox1.ValueMember = "Book_ID";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            payfine payfine = new payfine();
            payfine.Show();
            this.Hide();
        }
    }
}
