﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Reflection.Metadata.BlobBuilder;

namespace DBMS_PROJ
{
    public partial class studentform : Form
    {
        public studentform()
        {
            InitializeComponent();
        }
        const string constr = @"Data Source = DESKTOP-OGFUFDG\SPARTA; Initial Catalog=PROJECT; User ID=sa; Password=BRIGHTSHINES#95; Integrated Security=SSPI";
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cm = new SqlCommand();

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void backbutton_Click(object sender, EventArgs e)
        {
            studentlogin studentlogin = new studentlogin();
            studentlogin.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.DefaultCellStyle.ForeColor = Color.Black;
            con.Open();
            SqlCommand cmd3 = new SqlCommand("select Borrower_Details.Book_ID, Books.Book_Name, Issue_Date, Return_Date,Fine from Borrower_Details,Books where Books.Book_ID = Borrower_Details.Book_ID AND Student_ID = @stdid", con);
            cmd3.Parameters.AddWithValue("@stdid", textBox2.Text);
  
            SqlDataAdapter db = new SqlDataAdapter(cmd3);
            DataTable d1 = new DataTable();
            db.Fill(d1);
            dataGridView1.DataSource = d1;
          
            con.Close();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
