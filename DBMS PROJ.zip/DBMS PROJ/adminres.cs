﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBMS_PROJ
{
    public partial class adminres : Form
    {
        public adminres()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            newform addremove = new newform();
            addremove.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            borrowerform borrowerform = new borrowerform();
            borrowerform.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            inventorystatus inventorystatus = new inventorystatus();
            inventorystatus.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            loginform loginform = new loginform();
            loginform.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            bookallotment bookallotment = new bookallotment();
            bookallotment.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            returnbook returnbook = new returnbook();
            returnbook.Show();
            this.Hide();
        }
    }
}
